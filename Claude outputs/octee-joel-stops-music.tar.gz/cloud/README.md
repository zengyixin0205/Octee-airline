# Octee Cloud (the Worker behind "Cloud account")

A small Cloudflare Worker + D1 database. It stores a login and ONE saved JSON profile per user.

- Live at `https://octee-cloud-api.octee.workers.dev` (set as `CLOUD_URL` in `js/config.js`).
- API: `POST /api/register`, `POST /api/login`, `POST /api/claim` (etched accounts join the cloud), `GET|PUT /api/profile` (Bearer token), `POST /api/logout`, `GET /api/me`, `GET /api/reviews` (public), `PUT|DELETE /api/review` (one review per user).
- `index.js` is the Worker, `schema.sql` creates the tables (`users`, `sessions`, `profiles`, `attempts`, `reviews`).
- CORS only allows https://zengyixin0205.github.io (and localhost:8765 for testing). Change `ORIGINS` in `index.js` to add another site.
- Passwords: PBKDF2-SHA256 (100,000 rounds). Session tokens are stored hashed. 5 wrong logins locks that name+IP for 5 minutes; at most 5 new accounts per IP, then a 5 minute wait.
- PUT /api/profile: `{ profile, baseUpdatedAt }`. If someone else saved first the answer is 409 with the newer copy (the site then loads it).
- To redeploy with wrangler: create the D1 database, put its id in `wrangler.toml`, run `wrangler d1 execute octee-cloud --file schema.sql --remote`, then `wrangler deploy`.
- The profile is saved from the browser, but the **balances are owned by the cloud** (table `balances`: Octmiles, lifetime Octmiles, Octeetokens, Fujitech, Scraggymiles; see "Cloud-owned balances" below). Everything else in the profile is trusted from the browser. Do not reuse real passwords.

## JoelAI Pro ledger

- `GET /api/joel` (wallet and last 20 ledger rows), `POST /api/joel/unlock`, `POST /api/joel/buy {count}` (Bearer token), `POST /api/joel/charge` (only the model server: needs the `x-ledger-secret` header equal to the Worker secret `JOEL_LEDGER_SECRET`).
- Tables `joel_wallet` (Pro flag, bought JoelTokens, this month's use) and `joel_ledger` (every unlock, top-up and charge).
- Unlock and top-ups take Octeetokens from the saved profile with a compare-and-set on `updated_at`, so two devices cannot spend the same Octeetokens twice. Honest limit: Octeetokens are earned by the browser (miles, codes), so someone who edits their own profile can still give themselves Octeetokens. JoelTokens and Pro cannot be edited this way: the server overwrites those fields in the profile on every save and read.
- Set the secret with `wrangler secret put JOEL_LEDGER_SECRET` (or as a Worker secret binding) and use the same value as `JOEL_LEDGER_SECRET` on Vercel.


## Control Tower and cloud profile records

- Complaints (both desks), Gullet tickets, Normal Thursday entries and cargo shipments are included in cloud-linked account profiles and therefore sync on the existing profile save/pull cycle. Local-only accounts continue to save in the browser.
- Cloud-backed Control Tower access requires a valid Cloud session and a Worker role. Set the non-secret Worker variable `CONTROL_TOWER_OWNER_USERNAME` to the existing Cloud account that owns administration. Add `cloud_admins` using the updated `schema.sql`, for example by rerunning `wrangler d1 execute octee-cloud --file schema.sql --remote`, then deploy the updated Worker.
- After that owner signs into Octee Cloud, the Control Tower's Cloud accounts tab can list accounts and grant/revoke admin roles. The Worker checks the role for every `/api/admin/*` request; the hidden logo gesture only opens the interface. Admins need a Cloud account and must be granted a role by the owner.
- Flight discount codes are created in the static Control Tower and downloaded as `data/flight-discounts.json`; commit/push that file to publish. The file contains hashes, not the redeemable plain codes. Each code may specify percent off, destination, cabin and expiry.
- Passenger fare rules in this prototype: base 0.055 Fujitech per route mile, multiplied by cabin (Economy 1×, Business 1.5×, First 2×, Scraggy Class 2.5×); Platinum Wing uses 1×. Cargo uses 2.0 Fujitech handling plus 5.5 Fujitech per 50 route-miles per 10 kg. Exchange batches are 50 Octmiles → 5.5 Fujitech.
- The browser-side profile remains the source of balances; this Worker admin feature secures role checks, but fare balances are not server-ledgered. Do not treat Fujitech as real money.

## Control Tower saves to the cloud

- Table `published` holds the files the Control Tower used to download: `codes`, `accounts`, `permissions`, `control-tower` (the crew) and `flight-discounts`. `GET /api/data/<name>` is public; `PUT` needs a cloud login that is the Control Tower owner or an admin (the same role check as `/api/admin/*`).
- The site reads the cloud copy first and falls back to the file in `data/` (`js/published.js`), and the Worker's etched-account list does the same. Every Tower panel keeps a "Manual download" button for when the cloud has a problem.
- Run the new `published` table from `schema.sql`, then redeploy the Worker.
- `perks` is a fifth published file: `{ "unlimitedFujitech": { "octee": true } }`. Only the Control Tower (Accounts tab) can change it. The site reads it (`js/perks.js`) and `spendFujitech` skips the deduction for accounts listed there; the earned Fujitech balance is never touched.
- `ads` is a sixth published file: `{ "ads": [ { "title", "text", "icon", "link", "button", "image", "theme", "start", "end", "pages", "priority", "on" } ] }`, at most 30. The Worker checks it (`adOk`): plain text, links must be https:// or a page of the site, images https:// only. Public to read, owner/admin to write. Edited in the Control Tower Ads tab; shown by `js/ads.js`.
- Code usage limits: a code in the published `codes` file may have `maxUses`. `POST /api/code/claim {hash}` (login) takes one use (tables `code_uses`, `code_claims`; 410 `used_up`, 409 `already`), and `applyWallet` only credits a limited code when an unspent claim exists. `GET /api/admin/code-uses` (admin) returns the counts. Unlimited codes use `repeat: true, noLimit: true`.
- Reviews: table `review_posts` (many per account). `GET /api/reviews` (public, with ids); `POST /api/review` (or `PUT`, for older pages) writes one; `PUT /api/review/<id>` and `DELETE /api/review/<id>` change or remove your own. Limits `REVIEW_LIMITS` in `index.js`: 5 a day and 50 in all (429 `limit_day`/`limit_total`), one per `tripRef` (409 `trip_taken`). The old one-per-account table `reviews` is copied into `review_posts` once by the guarded `INSERT ... SELECT` at the end of `schema.sql`; run that file's `review_posts` statements on an existing database.
- Code viewer access: `GET /api/code/me` (role owner/viewer, else 403), `GET/POST/DELETE /api/code/viewers` (owner only; table `code_viewers`). Owners are `CODE_OWNERS` in `index.js` (etched, currently Octee) plus the Control Tower owner. Run the three new `CREATE TABLE` statements of `schema.sql` on an existing database.
- `music` is a seventh published file: `{ "tracks": [ { "id" } ] }`, at most 2. Each `id` is a bare YouTube video ID (`musicIdOk`: `/^[\w-]{6,20}$/`) — never the video or audio itself, and the Worker never fetches or stores anything from YouTube. Public to read, owner/admin to write. Edited in the Control Tower Music tab (which parses pasted links into bare IDs before saving); shown on every page by `js/tower-music.js`, which embeds YouTube's own IFrame player to play it. One track loops forever; two loop back to back.

## Cloud-owned balances
Octmiles, Octeetokens, Fujitech and Scraggymiles of a **cloud account** are kept by the Worker in the `balances` table. The browser still works the numbers out and writes a history line for each change; when it saves the account (`PUT /api/profile`) the Worker (`applyWallet` in `index.js`) reads only the **new** history lines:

- spending (negative amounts) is always accepted, and never takes a balance below zero;
- a credit is accepted only when a rule explains it: an exchange at the real rate (10 Octmiles = 1 Octeetoken, 50 Octmiles = 5.5 Fujitech, 1 Scraggymile = 2 Octmiles), a code that exists in `codes` (single use unless it repeats; the top-tier bonus and the permission grants are checked), a booking that really is in the account (up to 2,800 Octmiles per booking and 3,000 a day), the JOELMOBILE ride, the first review;
- everything else is dropped. If the cloud's numbers differ from what the browser claimed, the reply carries `corrected: true` and the saved copy, the browser takes it and shows a short notice.

The starting balance of an account is what it **already had saved in the cloud**; an etched account starts from its record in `accounts.json`; a brand-new cloud account starts with the 100 Octmiles welcome bonus (the progress of a local-only account is not imported when it is linked). Unlock and top-ups of JoelAI Pro take Octeetokens from this balance. Accounts that are not in the cloud keep working locally, with browser-owned numbers.
Honest limits: the browser still decides which bookings and rides happened, so those credits are rate-limited rather than proven; spending less than the real price is not detected; Scraggymiles taken from the shared pot of the other site are capped at 300 a day. Apply `schema.sql` (the `balances` table) before deploying.
